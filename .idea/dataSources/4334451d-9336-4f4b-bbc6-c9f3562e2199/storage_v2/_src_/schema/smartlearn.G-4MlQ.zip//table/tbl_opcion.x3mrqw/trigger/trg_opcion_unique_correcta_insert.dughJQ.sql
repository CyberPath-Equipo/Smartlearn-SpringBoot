create definer = root@localhost trigger trg_opcion_unique_correcta_insert
    before insert
    on tbl_opcion
    for each row
BEGIN
    IF NEW.es_correcta = 1 THEN
        IF EXISTS (SELECT 1 FROM tbl_opcion WHERE id_pregunta = NEW.id_pregunta AND es_correcta = 1) THEN
            SIGNAL SQLSTATE '45000' SET MESSAGE_TEXT = 'Solo una opción correcta por pregunta';
END IF;
END IF;
END;

